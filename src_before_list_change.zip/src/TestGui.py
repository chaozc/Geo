from Gui3 import *
from time import sleep

if __name__ == "__main__":
	
	argv = ['circle', 200, 200, 50]
	
	drawmain(argv)
	# for i in range(1,20):
	# 	sleep(0.5)
	# 	g.argv = ['circle', 200, 200, i*10]
	# sleep(1)
	# g.argv = ['circle', 200, 200, 100]
	# print g.argv