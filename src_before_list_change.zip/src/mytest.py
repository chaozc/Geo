from sympy.geometry import *
i = 0
for i in [i, i+1]:
	print i;

