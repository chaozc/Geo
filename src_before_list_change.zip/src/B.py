from A import AAA
class BBB:
	def funcb():
		print("Call A from b");
	AAA().funca()

AAA().funca