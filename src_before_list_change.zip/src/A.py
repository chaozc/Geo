
class AAA:
	"""docstring for AAA"""

	def funca():
		print("Call a from b");
	
